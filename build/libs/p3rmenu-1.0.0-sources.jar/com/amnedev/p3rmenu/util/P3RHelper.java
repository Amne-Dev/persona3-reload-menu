package com.amnedev.p3rmenu.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

public class P3RHelper {

    /**
     * Draws a rectangle with a skewed right edge.
     * Useful for the menu item highlight strips.
     */
    public static void drawSkewedStrip(class_332 context, int xStart, int y, int width, int height, int skewPixels,
            int color) {
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        float f = (float) (color >> 24 & 255) / 255.0F;
        float g = (float) (color >> 16 & 255) / 255.0F;
        float h = (float) (color >> 8 & 255) / 255.0F;
        float k = (float) (color & 255) / 255.0F;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Top Left
        bufferBuilder.method_22918(matrix, xStart, y, 0).method_22915(g, h, k, f).method_1344();
        // Bottom Left
        bufferBuilder.method_22918(matrix, xStart, y + height, 0).method_22915(g, h, k, f).method_1344();
        // Bottom Right (Skewed)
        bufferBuilder.method_22918(matrix, xStart + width - skewPixels, y + height, 0).method_22915(g, h, k, f).method_1344();
        // Top Right (Skewed)
        bufferBuilder.method_22918(matrix, xStart + width, y, 0).method_22915(g, h, k, f).method_1344();

        tessellator.method_1350();
        RenderSystem.disableBlend();
    }

    /**
     * Draws a fully skewed rectangle (parallelogram).
     */
    public static void drawSkewedRect(class_332 context, int x, int y, int width, int height, int skewOffset,
            int color) {
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        float a = (float) (color >> 24 & 255) / 255.0F;
        float r = (float) (color >> 16 & 255) / 255.0F;
        float g = (float) (color >> 8 & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Top Left
        bufferBuilder.method_22918(matrix, x + skewOffset, y, 0).method_22915(r, g, b, a).method_1344();
        // Bottom Left
        bufferBuilder.method_22918(matrix, x, y + height, 0).method_22915(r, g, b, a).method_1344();
        // Bottom Right
        bufferBuilder.method_22918(matrix, x + width, y + height, 0).method_22915(r, g, b, a).method_1344();
        // Top Right
        bufferBuilder.method_22918(matrix, x + width + skewOffset, y, 0).method_22915(r, g, b, a).method_1344();

        tessellator.method_1350();
        RenderSystem.disableBlend();
    }

    /**
     * Draws a quad with a left-skewed edge and a flat right edge.
     * This creates a shape like "/|".
     */
    public static void drawLeftSkewedRightFlatStrip(class_332 context, int x, int y, int width, int height, int skew,
            int color) {
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        float f = (float) (color >> 24 & 255) / 255.0F;
        float g = (float) (color >> 16 & 255) / 255.0F;
        float h = (float) (color >> 8 & 255) / 255.0F;
        float k = (float) (color & 255) / 255.0F;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        class_287 bufferBuilder = class_289.method_1348().method_1349();
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Quad:
        // Top-Left: (x + skew, y)
        // Bottom-Left: (x, y + height)
        // Bottom-Right: (x + width, y + height)
        // Top-Right: (x + width, y) <-- Flat Right Edge

        // Note: x is the "Leftmost Bottom" coordinate.

        float x1 = x + skew; // Top-Left
        float y1 = y;

        float x2 = x; // Bottom-Left
        float y2 = y + height;

        float x3 = x + width; // Bottom-Right
        float y3 = y + height;

        float x4 = x + width; // Top-Right
        float y4 = y;

        bufferBuilder.method_22918(matrix, x2, y2, 0).method_22915(g, h, k, f).method_1344(); // BL
        bufferBuilder.method_22918(matrix, x3, y3, 0).method_22915(g, h, k, f).method_1344(); // BR
        bufferBuilder.method_22918(matrix, x4, y4, 0).method_22915(g, h, k, f).method_1344(); // TR
        bufferBuilder.method_22918(matrix, x1, y1, 0).method_22915(g, h, k, f).method_1344(); // TL

        class_286.method_43433(bufferBuilder.method_1326());
        RenderSystem.disableBlend();
    }

    /**
     * Draws a skewed rectangle with a gradient.
     */
    public static void drawGradientSkewedRect(class_332 context, int x, int y, int width, int height, int skewOffset,
            int colorStart, int colorEnd) {
        Matrix4f matrix = context.method_51448().method_23760().method_23761();

        float alpha1 = (float) (colorStart >> 24 & 255) / 255.0F;
        float red1 = (float) (colorStart >> 16 & 255) / 255.0F;
        float green1 = (float) (colorStart >> 8 & 255) / 255.0F;
        float blue1 = (float) (colorStart & 255) / 255.0F;

        float alpha2 = (float) (colorEnd >> 24 & 255) / 255.0F;
        float red2 = (float) (colorEnd >> 16 & 255) / 255.0F;
        float green2 = (float) (colorEnd >> 8 & 255) / 255.0F;
        float blue2 = (float) (colorEnd & 255) / 255.0F;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        // Use Gouraud shading for gradient
        // RenderSystem.shadeModel intentionally removed for 1.20+

        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // Top Left (Start Color)
        bufferBuilder.method_22918(matrix, x + skewOffset, y, 0).method_22915(red1, green1, blue1, alpha1).method_1344();
        // Bottom Left (Start Color)
        bufferBuilder.method_22918(matrix, x, y + height, 0).method_22915(red1, green1, blue1, alpha1).method_1344();
        // Bottom Right (End Color)
        bufferBuilder.method_22918(matrix, x + width, y + height, 0).method_22915(red2, green2, blue2, alpha2).method_1344();
        // Top Right (End Color)
        bufferBuilder.method_22918(matrix, x + width + skewOffset, y, 0).method_22915(red2, green2, blue2, alpha2).method_1344();

        tessellator.method_1350();
        // RenderSystem.shadeModel intentionally removed for 1.20+
        RenderSystem.disableBlend();
    }
}
