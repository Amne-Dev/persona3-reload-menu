package com.amnedev.p3rmenu.mixin;

import com.amnedev.p3rmenu.util.TransitionManager;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (TransitionManager.isBlockingInput() && action == 1) { // 1 = Press
            ci.cancel();
        }
    }
}
