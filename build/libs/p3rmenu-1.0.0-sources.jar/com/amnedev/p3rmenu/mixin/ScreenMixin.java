package com.amnedev.p3rmenu.mixin;

import com.amnedev.p3rmenu.util.TransitionManager;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_437.class)
public class ScreenMixin {

    @Inject(method = "init(Lnet/minecraft/client/MinecraftClient;II)V", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        // When any screen initializes, start the IN transition (reveal)
        TransitionManager.startIn();
    }

    @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;)V", at = @At("HEAD"), cancellable = true)
    private void p3rmenu_onRenderBackground(class_332 context, CallbackInfo ci) {
        class_437 self = (class_437) (Object) this;
        class_310 client = class_310.method_1551();
        
        // If we are in menus (not in a world), replace the Dirt background with Cobalt Blue
        if (client.field_1687 == null) {
            // Cobalt Blue (approximate P3R deep blue: 0xFF003380)
            context.method_25294(0, 0, self.field_22789, self.field_22790, 0xFF003380);
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_437 self = (class_437) (Object) this;
        // System.out.println("Rendering Screen: " + self.getClass().getName()); // Debug

        TransitionManager.render(context, delta, self.field_22789, self.field_22790);
    }
}
