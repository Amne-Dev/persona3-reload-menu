package com.amnedev.p3rmenu.mixin;

import com.amnedev.p3rmenu.util.P3RHelper;
import com.amnedev.p3rmenu.util.TransitionManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7833;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    private static final class_2960 BACKGROUND_TEXTURE = new class_2960("p3rmenu",
            "textures/gui/title/p3r_background.png");
    private static final class_2960 LOGO_TEXTURE = new class_2960("p3rmenu",
            "textures/gui/title/p3r_logo.png");
    private static final int COLOR_WHITE = 0xFFFFFFFF;
    private static final int COLOR_BLUE_STRIP = 0xFF0044FF; // Cobalt Blue
    private static final int COLOR_CYAN = 0xFF00FFFF;
    private static final int COLOR_COBALT = 0xFF0044FF;

    // Transition State handled by TransitionManager

    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void p3r_init(CallbackInfo ci) {

        // Hide all buttons initially
        for (net.minecraft.class_364 element : this.method_25396()) {
            if (element instanceof class_339 widget) {
                widget.field_22764 = false;
            }
        }
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void p3r_render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        ci.cancel();

        // 1. Render Background (Custom Texture)
        RenderSystem.enableBlend();
        context.method_25291(BACKGROUND_TEXTURE, 0, 0, 0, 0.0F, 0.0F, this.field_22789, this.field_22790, this.field_22789, this.field_22790);
        RenderSystem.disableBlend();

        // 2. Render Logo (Top-Right)
        renderP3RLogo(context);

        // 3. Render Dynamic Menu (Bottom-Right)
        renderP3RMenu(context, mouseX, mouseY);

        // 4. Footer (Accessibility / Quit)
        renderFooter(context, mouseX, mouseY);

        // 5. Render Transition Overlay (if active)
        TransitionManager.render(context, delta, this.field_22789, this.field_22790);
    }



    private void renderP3RLogo(class_332 context) {
        context.method_51448().method_22903();

        // Top-Right Anchor
        int baseX = this.field_22789 - 120;
        int baseY = 80;

        // Rotation -5 degrees
        context.method_51448().method_46416(baseX, baseY, 0);
        context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-5.0f));


        int targetWidth = 120;
        int targetHeight = (int) (targetWidth * (800.0f / 900.0f));

        // Draw texture centered on the anchor
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        // Enable Linear filtering for smooth scaling
        RenderSystem.setShaderTexture(0, LOGO_TEXTURE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

        // Draw centered. 
        // drawTexture(texture, x, y, width, height, u, v, regionWidth, regionHeight, textureWidth, textureHeight)
        // We map the full texture (targetWidth x targetHeight in "texture pixels" abstraction) to the quad.
        context.method_25291(LOGO_TEXTURE, -targetWidth / 2, -targetHeight / 2, 0, 0.0f, 0.0f, targetWidth, targetHeight, targetWidth, targetHeight);
        
        RenderSystem.disableBlend();

        context.method_51448().method_22909();
    }

    // Helper for consistency
    private boolean shouldHideItem(String msg) {
        if (msg.isEmpty())
            return true;
        if (msg.contains("Copyright"))
            return true;
        if (msg.contains("Accessib"))
            return true; // Broader check
        if (msg.equals("Language"))
            return true;
        if (msg.equals("Quit Game"))
            return true;
        return false;
    }

    private java.util.Map<class_339, Float> hoverProgress = new java.util.HashMap<>();

    private void renderP3RMenu(class_332 context, int mouseX, int mouseY) {
        // 1. Calculate valid items
        java.util.List<class_339> validItems = new java.util.ArrayList<>();
        for (net.minecraft.class_364 element : this.method_25396()) {
            if (element instanceof class_339 widget) {
                if (!shouldHideItem(widget.method_25369().getString())) {
                    validItems.add(widget);
                }
            }
        }

        int count = validItems.size();
        if (count == 0)
            return;

        // Dynamic Scaling (Count + GUI Scale)
        float baseScale = 1.0f;
        if (count > 5) {
            baseScale = 1.0f - ((count - 5) * 0.08f);
            if (baseScale < 0.6f)
                baseScale = 0.6f;
        }

        // Enforce max scale relative to screen (Target Scale 3.0 for bigger buttons)
        double guiFactor = this.field_22787.method_22683().method_4495();
        float scaleCorrection = (guiFactor > 2.0) ? (float) (3.0 / guiFactor) : 1.5f;

        float finalScale = baseScale * scaleCorrection;
        int stepY = (int) (25 * finalScale);
        // Ensure minimum spacing
        if (stepY < 12)
            stepY = 12;

        int totalHeight = count * stepY;

        // Layout
        int safeTop = 130;
        int safeBottom = this.field_22790 - 40;
        int startY = safeTop + (safeBottom - safeTop) / 2 - (totalHeight / 2);

        if (startY < safeTop)
            startY = safeTop;
        if (startY + totalHeight > safeBottom)
            startY = safeBottom - totalHeight;

        int rightMargin = 40;

        // 2. Render Check & Animation Frame Time
        float animSpeed = 0.4f;

        context.method_51448().method_22903();

        for (int i = 0; i < count; i++) {
            class_339 widget = validItems.get(i);
            String msg = widget.method_25369().getString();

            int y = startY + (i * stepY);

            int textWidthBase = this.field_22793.method_1727(msg);
            int textWidth = (int) (textWidthBase * finalScale);

            int x = this.field_22789 - rightMargin - textWidth;

            // EXPANDED HITBOX (Matches Visuals)
            // Visuals: Text ends at Right Edge (x+textWidth).
            // Strip: Extends 10px Right, ~25px Left.
            // Hitbox: Let's be generous. -30 Left, +20 Right.
            int hitX = x - 30;
            int hitW = textWidth + 50;
            int hitY = y - 5;
            int hitH = (int) (20 * finalScale);

            boolean hovered = (mouseX >= hitX && mouseX <= hitX + hitW && mouseY >= hitY && mouseY <= hitY + hitH);

            // Animation Logic
            float currentProgress = hoverProgress.getOrDefault(widget, 0.0f);
            float target = hovered ? 1.0f : 0.0f;

            // Simple Lerp
            float nextProgress = currentProgress + (target - currentProgress) * animSpeed;
            if (Math.abs(target - nextProgress) < 0.01f)
                nextProgress = target;

            hoverProgress.put(widget, nextProgress);

            context.method_51448().method_22903();
            context.method_51448().method_46416(x, y, 0);
            context.method_51448().method_22905(finalScale, finalScale, 1.0f);

            if (nextProgress > 0.01f) {
                // Skewed Strip Animation
                // Slide in from RIGHT EDGE OF SCREEN

                // Visual Right Edge in local coords = textWidthBase + (rightMargin / scale)
                // Added +50 buffer to ensure it extends fully off-screen without gaps
                int localScreenRight = textWidthBase + (int) (rightMargin / finalScale) + 50;

                // We want to fill from Right Edge up to a bit past the text start (e.g. -20)
                int fullStripWidth = localScreenRight + 30;
                int currentStripWidth = (int) (fullStripWidth * nextProgress);

                int stripStart = localScreenRight - currentStripWidth;

                if (currentStripWidth > 0) {
                    // Skew 10px, Angle Left /|, Flat Right
                    P3RHelper.drawLeftSkewedRightFlatStrip(context, stripStart, -4, currentStripWidth, 18, 10,
                            COLOR_BLUE_STRIP);
                }
            }

            // Text Interaction
            // "Closer to shadow" -> Max offset 2px.
            // "Only set distance on hover" -> Default 0 distance.
            // Shadow at (2, 2)
            float popFactor = nextProgress;

            // textX calculated from existing popFactor
            float textX = -5.0f * popFactor;

            // Shadow: Follows text (textX + 1, 1)
            // Just standard offset from the dynamic text position
            context.method_51433(this.field_22793, msg, (int) textX + 1, 1, 0xFF000000, false);

            // Text: Slides Left
            context.method_51433(this.field_22793, msg, (int) textX, 0, hovered ? COLOR_WHITE : 0xFFEEEEEE, false);

            context.method_51448().method_22909();
        }
        context.method_51448().method_22909();
    }

    private void renderFooter(class_332 context, int mouseX, int mouseY) {
        String accessText = "[LT] Accessibility";
        String exitText = "[=] End Game";

        int y = this.field_22790 - 20;

        int exitWidth = this.field_22793.method_1727(exitText);
        int exitX = this.field_22789 - exitWidth - 20;

        int accessWidth = this.field_22793.method_1727(accessText);
        int accessX = exitX - accessWidth - 30;

        boolean accessHover = (mouseX >= accessX && mouseX <= accessX + accessWidth && mouseY >= y && mouseY <= y + 10);
        context.method_51433(this.field_22793, accessText, accessX, y, accessHover ? COLOR_CYAN : 0xFFAAAAAA, true);

        boolean exitHover = (mouseX >= exitX && mouseX <= exitX + exitWidth && mouseY >= y && mouseY <= y + 10);
        context.method_51433(this.field_22793, exitText, exitX, y, exitHover ? 0xFFFF4444 : 0xFFAAAAAA, true);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button != 0)
            return super.method_25402(mouseX, mouseY, button);

        // 1. Menu Items Logic (SYNC WITH RENDER)
        java.util.List<class_339> validItems = new java.util.ArrayList<>();
        for (net.minecraft.class_364 element : this.method_25396()) {
            if (element instanceof class_339 widget) {
                if (!shouldHideItem(widget.method_25369().getString())) {
                    validItems.add(widget);
                }
            }
        }

        int count = validItems.size();
        if (count > 0) {
            float baseScale = 1.0f;
            if (count > 5) {
                baseScale = 1.0f - ((count - 5) * 0.08f);
                if (baseScale < 0.6f)
                    baseScale = 0.6f;
            }

            double guiFactor = this.field_22787.method_22683().method_4495();
            float scaleCorrection = (guiFactor > 2.0) ? (float) (3.0 / guiFactor) : 1.5f;
            float finalScale = baseScale * scaleCorrection;
            int stepY = (int) (25 * finalScale);
            if (stepY < 12)
                stepY = 12;

            int totalHeight = count * stepY;
            int safeTop = 130;
            int safeBottom = this.field_22790 - 40;
            int startY = safeTop + (safeBottom - safeTop) / 2 - (totalHeight / 2);
            if (startY < safeTop)
                startY = safeTop;
            if (startY + totalHeight > safeBottom)
                startY = safeBottom - totalHeight;

            int rightMargin = 40;

            for (int i = 0; i < count; i++) {
                class_339 widget = validItems.get(i);
                String msg = widget.method_25369().getString();

                int y = startY + (i * stepY);
                int textWidth = (int) (this.field_22793.method_1727(msg) * finalScale);
                int x = this.field_22789 - rightMargin - textWidth;

                // Match Render Hitbox
                int hitX = x - 30;
                int hitW = textWidth + 50;
                int hitY = y - 5;
                int hitH = (int) (20 * finalScale);

                if (mouseX >= hitX && mouseX <= hitX + hitW && mouseY >= hitY && mouseY <= hitY + hitH) {
                    if (!TransitionManager.isTransitioning()) {
                        widget.method_25354(this.field_22787.method_1483());
                        
                        // Start OUT Transition
                        TransitionManager.startOut(() -> {
                            if (widget instanceof class_4264 pressable) {
                                pressable.method_25306();
                            } else {
                                widget.method_25348(mouseX, mouseY);
                            }
                        });
                    }
                    return true;
                }
            }
        }

        // 2. Footer (Keep standard logic or check P3RHelper for footer hitbox?)
        // Footer is fine as is.
        return footerMouseClicked(mouseX, mouseY);
    }

    // Extracted footer logic to avoid code dup if needed, or just inline
    private boolean footerMouseClicked(double mouseX, double mouseY) {
        if (TransitionManager.isTransitioning()) return true; // Block input during transition

        // Footer
        int y = this.field_22790 - 20;
        String exitText = "[=] End Game";
        String accessText = "[LT] Accessibility";

        int exitWidth = this.field_22793.method_1727(exitText);
        int exitX = this.field_22789 - exitWidth - 20;

        int accessWidth = this.field_22793.method_1727(accessText);
        int accessX = exitX - accessWidth - 30;

        // Accessibility
        if (mouseX >= accessX && mouseX <= accessX + accessWidth && mouseY >= y && mouseY <= y + 10) {
            for (net.minecraft.class_364 element : this.method_25396()) {
                if (element instanceof class_339 widget) {
                    if (widget.method_25369().getString().contains("Accessib")) {
                        widget.method_25354(this.field_22787.method_1483());
                        // Instant action for accessibility
                        ((class_4264) widget).method_25306();
                        return true;
                    }
                }
            }
            return true;
        }

        // Quit
        if (mouseX >= exitX && mouseX <= exitX + exitWidth && mouseY >= y && mouseY <= y + 10) {
             if (!TransitionManager.isTransitioning()) {
                 this.field_22787.method_1483().method_4873(net.minecraft.class_1109.method_47978(net.minecraft.class_3417.field_15015, 1.0F));
                 
                 // Start Transition for Quit too
                 TransitionManager.startOut(() -> this.field_22787.method_1592());
             }
            return true;
        }
        return false;
    }
}
